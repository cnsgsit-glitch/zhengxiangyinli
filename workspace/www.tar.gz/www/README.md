# 潘建瓴 - 个人官网

这是一个单页官网，展示你的五大核心业务。

## 文件结构

```
www/
└── index.html   # 主页面
```

## 本地预览

直接在浏览器打开 `index.html` 即可预览。

## 部署上线

### 方案1：Vercel（免费，最快）
```bash
# 安装 Vercel CLI
npm i -g vercel

# 进入目录部署
cd www
vercel
```

### 方案2：Netlify（免费）
直接拖拽 `www` 文件夹到 Netlify Drop 即可上线。

### 方案3：GitHub Pages
1. 创建 GitHub 仓库
2. 上传 index.html
3. Settings → Pages → 选择 main branch

## 下一步优化

- [ ] 添加客户案例页面
- [ ] 添加文章/博客
- [ ] 添加在线报名表单
- [ ] 绑定自定义域名
- [ ] 添加 SEO 优化
- [ ] 添加数据分析
